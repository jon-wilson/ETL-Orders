-- CREATE DATABASE FairfieldUDW;
-- GO

USE FairfieldUDW;
GO 

-- CREATE SCHEMA Dim
-- GO
-- CREATE SCHEMA Fact
-- GO

DROP TABLE Fact.Orders
DROP TABLE Dim.Customers
DROP TABLE Dim.Dates
DROP TABLE Dim.Employees
DROP TABLE Dim.Geography
DROP TABLE Dim.Products
GO

CREATE TABLE Dim.Customers (
	CustomerKey				NVARCHAR(20)	NOT NULL
	,GeographyKey			NVARCHAR(20)	NOT NULL
    ,CustomerAlternateKey	NVARCHAR(20)	NOT NULL
    ,FirstName				NVARCHAR(30)
    ,MiddleName				NVARCHAR(30)
    ,LastName				NVARCHAR(30)
	,BirthDate				DATETIME
	,MaritalStatus			NVARCHAR(1)
	,Gender					NVARCHAR(1)
    ,EmailAddress			NVARCHAR(255)
    ,YearlyIncome			NUMERIC(11, 2)
    ,TotalChildren			INT
    ,NumberChildrenAtHome	INT
    ,HouseOwnerFlag			BIT				NOT NULL
    ,NumberCarsOwned		INT
	,AddressLine1			NVARCHAR(255)
	,Phone					NVARCHAR(20)
	,DateFirstPurchase		DATETIME
    ,PRIMARY KEY(CustomerKey)
);
GO

CREATE TABLE Dim.Dates (
    DateKey				NVARCHAR(8)	        NOT NULL
    ,FullDate			DATETIME
    ,DayName            NVARCHAR(20)
    ,DayNumber          INT
    ,MonthName          NVARCHAR(20)
    ,MonthNumber        INT
    ,QuarterNumber      INT
    ,Year               INT
    ,PRIMARY KEY(DateKey)
);
GO
CREATE TABLE Dim.Employees (
    EmployeeKey             NVARCHAR(20)    NOT NULL
	,ParentEmployeeKey      NVARCHAR(20)    NOT NULL
    ,SalesTerritoryKey      NVARCHAR(8)     NOT NULL
    ,FirstName				NVARCHAR(30)
    ,MiddleName				NVARCHAR(30)
    ,LastName				NVARCHAR(30)
    ,NameStyle				INT
    ,Title  				NVARCHAR(50)
    ,HireDate  				DATETIME
    ,BirthDate  			DATETIME
    ,EmailAddress			NVARCHAR(50)
    ,Phone  				NVARCHAR(20)
    ,MaritalStatus  		NVARCHAR(1)
    ,SalariedFlag  			BIT
    ,Gender  		        NVARCHAR(1)
    ,PayFrequency  		    BIT
    ,BaseRate			    NUMERIC(8, 4)
    ,VacationHours          INT
    ,SickLeaveHours  		INT
    ,DepartmentName  	    NVARCHAR(50)
    ,StartDate  			DATETIME        NOT NULL
    ,EndDate  			    DATETIME
    ,PRIMARY KEY(EmployeeKey)
);
GO

CREATE TABLE Dim.Geography (
    GeographyKey                NVARCHAR(20)	    NOT NULL
    ,City                       NVARCHAR(50)        NOT NULL
    ,StateProvinceCode          NVARCHAR(8)
	,StateProvinceName          NVARCHAR(50)
	,CountryRegionCode          NVARCHAR(8)
	,EnglishCountryRegionName   NVARCHAR(50)
	,SpanishCountryRegionName   NVARCHAR(50)
	,FrenchCountryRegionName    NVARCHAR(50)
	,PostalCode                 NVARCHAR(10)
	,SalesTerritoryKey          NVARCHAR(20)	    NOT NULL
    ,PRIMARY KEY(GeographyKey)
);
GO

CREATE TABLE Dim.Products (
    ProductKey           NVARCHAR(20)	    NOT NULL
	,Title               NVARCHAR(255)
    ,Description         NVARCHAR(255) 
	,Price               NUMERIC(11, 2)
	,DiscountPercentage  NUMERIC(4, 2) 
	,Rating              NUMERIC(3, 2)
	,Stock               INT 
	,Brand               NVARCHAR(40)
	,Category            NVARCHAR(30) 
	,Thumbnail           NVARCHAR(MAX) 
	,Images              NVARCHAR(MAX)
    ,PRIMARY KEY(ProductKey)
);
GO

CREATE TABLE Fact.Orders (
    Id                  INT             	NOT NULL    IDENTITY(1, 1)
    ,CustomerKey        NVARCHAR(20)
    ,DateKey            NVARCHAR(8)
    ,EmployeeKey        NVARCHAR(20)
    ,GeophraphyKey      NVARCHAR(20)
    ,ProductKey         NVARCHAR(20)
    ,OrderQuantity      INT
    ,PRIMARY KEY(Id)
    ,FOREIGN KEY(CustomerKey)   REFERENCES Dim.Customers(CustomerKey)
    ,FOREIGN KEY(DateKey)       REFERENCES Dim.Dates(DateKey)
    ,FOREIGN KEY(EmployeeKey)   REFERENCES Dim.Employees(EmployeeKey)
    ,FOREIGN KEY(GeophraphyKey) REFERENCES Dim.Geography(GeographyKey)
    ,FOREIGN KEY(ProductKey)    REFERENCES Dim.Products(ProductKey)
);
GO