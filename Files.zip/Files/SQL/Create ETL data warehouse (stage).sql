CREATE DATABASE FairfieldUDW_Stage;
GO

USE FairfieldUDW_Stage;
GO 

CREATE SCHEMA Fact;
GO
CREATE SCHEMA Dim;
GO

--DROP TABLE Fact.Orders
--DROP TABLE Dim.Customers
--DROP TABLE Dim.Dates
--DROP TABLE Dim.Products
--GO

CREATE TABLE Dim.Customers (
	CustomerKey NVARCHAR(255)
    ,CustomerAlternateKey NVARCHAR(255)
    ,FirstName NVARCHAR(255)
    ,LastName NVARCHAR(255)
	,FullName NVARCHAR(255)
    ,Address NVARCHAR(255)
    ,Phone NVARCHAR(255)
    ,EmailAddress NVARCHAR(255)
);
GO

CREATE TABLE Dim.Dates (
    DateKey NVARCHAR(255),
    FullDate NVARCHAR(255),
    DayName NVARCHAR(255),
    DayNumber NVARCHAR(255),
    MonthName NVARCHAR(255),
    MonthNumber NVARCHAR(255),
    QuarterNumber NVARCHAR(255),
    Year NVARCHAR(255)
);
GO

CREATE TABLE Dim.Products (
	ProductKey NVARCHAR(255),
	Title NVARCHAR(255),
	Description NVARCHAR(255), 
	Price NVARCHAR(255),
	DiscountPercentage NVARCHAR(255), 
	Rating NVARCHAR(255),
	Stock NVARCHAR(255), 
	Brand NVARCHAR(255),
	Category NVARCHAR(255), 
	Thumbnail NVARCHAR(255), 
	Images NVARCHAR(MAX)
);
GO

CREATE TABLE Fact.Orders (
    DateKey NVARCHAR(255),
    CustomerKey NVARCHAR(255),
    ProductKey NVARCHAR(255),
    OrderQuantity NVARCHAR(255)
);
GO